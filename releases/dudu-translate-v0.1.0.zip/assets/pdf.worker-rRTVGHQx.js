const r="/assets/pdf.worker-BgryrOlp.mjs";export{r as default};
//# sourceMappingURL=pdf.worker-rRTVGHQx.js.map
