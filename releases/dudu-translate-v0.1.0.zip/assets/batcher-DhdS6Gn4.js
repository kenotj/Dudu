function u(o){return new Promise((s,n)=>{try{chrome.runtime.sendMessage(o,r=>{const t=chrome.runtime.lastError;if(t){n(new Error(t.message));return}s(r)})}catch(r){n(r)}})}let e=0;function i(){return e=e+1>>>0,`s${e.toString(36)}`}export{i as n,u as s};
//# sourceMappingURL=batcher-DhdS6Gn4.js.map
