function r(n){let t=2166136261;for(let e=0;e<n.length;e++)t^=n.charCodeAt(e),t=Math.imul(t,16777619)>>>0;return t.toString(36)}function a(n){return r(n.map(t=>t===void 0?"":String(t)).join(""))}export{a as c,r as f};
//# sourceMappingURL=hash-CaSj1G5E.js.map
